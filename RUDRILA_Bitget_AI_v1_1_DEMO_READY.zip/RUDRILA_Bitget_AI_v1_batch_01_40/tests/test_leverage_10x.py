import os,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
os.environ['RUDRILA_MODE']='demo'; os.environ['LIVE_TRADING']='false'
from rudrila.rest_client import BitgetREST
from rudrila.settings import BitgetSettings

class R(BitgetREST):
    def __init__(self): self.calls=[]
    def _request(self,method,path,**kw):
        self.calls.append((method,path,kw))
        if path.endswith('/set-leverage'):
            return {'code':'00000','data':{'crossMarginLeverage':'10'}}
        return {'code':'00000','data':{'crossMarginLeverage':'10'}}

class LeverageTests(unittest.TestCase):
    def test_classic_set_10x(self):
        r=R(); out=r.classic_set_leverage('ETHUSDT',10,'USDT')
        m,p,k=r.calls[-1]
        self.assertEqual((m,p),('POST','/api/v2/mix/account/set-leverage'))
        self.assertEqual(k['body']['leverage'],'10')
        self.assertEqual(k['body']['marginCoin'],'USDT')
        self.assertTrue(k['private'])
        self.assertEqual(out['data']['crossMarginLeverage'],'10')
    def test_single_account_verification_endpoint(self):
        r=R(); r.classic_single_account('BTCUSDT','USDT')
        m,p,k=r.calls[-1]
        self.assertEqual((m,p),('GET','/api/v2/mix/account/account'))
        self.assertEqual(k['query']['symbol'],'BTCUSDT')
        self.assertEqual(k['query']['productType'],'USDT-FUTURES')

if __name__=='__main__': unittest.main()
