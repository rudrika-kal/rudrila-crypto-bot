# RUDRILA Bitget AI v1.1.6

- Signals now use Bitget production public WebSocket market data so BTC/ETH spread, depth, trades and candles match the real market.
- Private WebSocket, credentials and order execution remain Bitget Demo only.
- Keeps v1.1.5 fast-move directional-core logic and all safety/risk gates.
- LIVE_TRADING remains hard-disabled.
