from __future__ import annotations
from dataclasses import dataclass

@dataclass
class BreakingNewsState:
    active: bool=False
    direction: str="NEUTRAL"
    until_ms: int=0
    headline: str=""
    impact: float=0.0

class BreakingNewsGuard:
    def __init__(self, freeze_ms=60_000, extreme_score=70):
        self.freeze_ms=freeze_ms
        self.extreme_score=extreme_score
        self.state=BreakingNewsState()

    def ingest(self, signed_news_score:float, headline:str, now_ms:int)->BreakingNewsState:
        if abs(signed_news_score)>=self.extreme_score:
            self.state=BreakingNewsState(
                True,
                "LONG" if signed_news_score>0 else "SHORT",
                now_ms+self.freeze_ms,
                headline,
                abs(signed_news_score)
            )
        return self.state

    def evaluate(self, now_ms:int, price_return_pct:float, orderflow_direction:str)->dict:
        s=self.state
        if not s.active:
            return {"allow":True,"reason":"no breaking-news lock","confirmed_direction":"NEUTRAL"}
        if now_ms < s.until_ms:
            return {"allow":False,"reason":"breaking-news freeze","confirmed_direction":s.direction}
        # Require price and order flow to confirm headline direction after the freeze.
        price_dir="LONG" if price_return_pct>0.05 else ("SHORT" if price_return_pct<-0.05 else "NEUTRAL")
        confirmed=(price_dir==s.direction and orderflow_direction==s.direction)
        self.state.active=False
        return {"allow":confirmed,
                "reason":"breaking-news confirmed" if confirmed else "breaking-news reaction not confirmed",
                "confirmed_direction":s.direction if confirmed else "NEUTRAL"}
