from __future__ import annotations
import asyncio,json,time
import websockets
from .market_state import SymbolState

def _f(d, key, old=None):
    x=d.get(key)
    try: return float(x) if x not in (None,"") else old
    except (TypeError,ValueError): return old

class BitgetPublicDemoWS:
    def __init__(self,settings,symbols=('BTCUSDT','ETHUSDT')):
        self.settings=settings
        self.symbols=tuple(symbols)
        self.states={s:SymbolState(s) for s in self.symbols}
        self._stop=asyncio.Event()

    def subscriptions(self):
        args=[]
        for s in self.symbols:
            args += [
              {'instType':'usdt-futures','topic':'ticker','symbol':s},
              {'instType':'usdt-futures','topic':'publicTrade','symbol':s},
              {'instType':'usdt-futures','topic':'books5','symbol':s},
              {'instType':'usdt-futures','topic':'kline','symbol':s,'interval':'1m'},
              {'instType':'usdt-futures','topic':'kline','symbol':s,'interval':'5m'},
              {'instType':'usdt-futures','topic':'kline','symbol':s,'interval':'15m'}]
        return args

    async def heartbeat(self,ws):
        while not self._stop.is_set():
            await asyncio.sleep(30)
            await ws.send('ping')

    def handle(self,msg):
        arg=msg.get('arg') or {}
        sym=arg.get('symbol')
        topic=arg.get('topic')
        if sym not in self.states: return
        st=self.states[sym]
        ts=int(msg.get('ts') or time.time()*1000)
        data=msg.get('data') or []
        if topic=='ticker' and data:
            d=data[0]
            st.last_price=_f(d,'lastPrice',st.last_price)
            st.bid=_f(d,'bid1Price',st.bid)
            st.ask=_f(d,'ask1Price',st.ask)
            st.mark_price=_f(d,'markPrice',st.mark_price)
            st.index_price=_f(d,'indexPrice',st.index_price)
            st.funding_rate=_f(d,'fundingRate',st.funding_rate)
            st.open_interest=_f(d,'openInterest',st.open_interest)
            st.volume24h=_f(d,'volume24h',st.volume24h)
            nft=d.get('nextFundingTime')
            try: st.next_funding_time=int(nft) if nft not in (None,'') else st.next_funding_time
            except (TypeError,ValueError): pass
            st.touch(ts)
        elif topic=='publicTrade':
            for d in data: st.trades.append(d)
            st.touch(ts)
        elif topic=='books5' and data:
            st.books5=data[0]
            st.touch(ts)
        elif topic=='kline':
            interval=arg.get('interval')
            for row in data: st.candles[interval].append(row)
            st.touch(ts)

    async def run_once(self,seconds=20):
        self._stop=asyncio.Event()
        async with websockets.connect(self.settings.public_ws_demo,ping_interval=None,close_timeout=5) as ws:
            await ws.send(json.dumps({'op':'subscribe','args':self.subscriptions()}))
            hb=asyncio.create_task(self.heartbeat(ws))
            end=time.monotonic()+seconds
            try:
                while time.monotonic()<end:
                    raw=await asyncio.wait_for(ws.recv(),timeout=35)
                    if raw=='pong': continue
                    msg=json.loads(raw)
                    if msg.get('event')=='error':
                        raise RuntimeError(f'Bitget WS error: {msg}')
                    self.handle(msg)
            finally:
                self._stop.set()
                hb.cancel()
        return self.states
