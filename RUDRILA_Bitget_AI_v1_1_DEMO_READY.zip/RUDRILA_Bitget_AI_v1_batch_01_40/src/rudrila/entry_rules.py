from __future__ import annotations
from dataclasses import dataclass
from .consensus import ConsensusResult

@dataclass(frozen=True)
class EntryDecision:
    enter: bool
    side: str
    required_score: float
    actual_score: float
    aligned_families: int
    reason: str

class EntryRules:
    def __init__(self, base=82, min_aligned=5):
        self.base=base
        self.min_aligned=min_aligned
    def threshold(self, regime:str)->float:
        return {
          "TREND":80.0,
          "BREAKOUT":84.0,
          "RANGE":86.0,
          "PANIC":999.0,
          "LOW_LIQUIDITY":999.0
        }.get(regime, self.base)
    def decide(self, c:ConsensusResult, regime:str, breaking_allow:bool=True,
               risk_allow:bool=True, cooldown:bool=False)->EntryDecision:
        req=self.threshold(regime)
        score=c.long_score if c.direction=="LONG" else c.short_score if c.direction=="SHORT" else 0
        reasons=[]
        if c.direction=="NEUTRAL": reasons.append("neutral consensus")
        if c.veto: reasons.append("hard veto")
        if c.aligned_families<self.min_aligned: reasons.append("not enough independent families")
        if score<req: reasons.append("score below threshold")
        if not breaking_allow: reasons.append("breaking-news guard")
        if not risk_allow: reasons.append("risk gate")
        if cooldown: reasons.append("cooldown")
        ok=not reasons
        return EntryDecision(ok,c.direction if ok else "NONE",req,score,c.aligned_families,
                             "entry approved" if ok else "; ".join(reasons))
