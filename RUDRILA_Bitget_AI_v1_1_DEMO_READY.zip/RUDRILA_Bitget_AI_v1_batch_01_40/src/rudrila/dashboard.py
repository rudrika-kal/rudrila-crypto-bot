from __future__ import annotations
import html,json
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path

class DashboardHandler(BaseHTTPRequestHandler):
    health_path=Path('runtime/health.json')
    def do_GET(self):
        data=json.loads(self.health_path.read_text()) if self.health_path.exists() else {'status':'unknown'}
        if self.path=='/health.json':
            b=json.dumps(data).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b); return
        rows=''.join(f'<tr><th>{html.escape(str(k))}</th><td>{html.escape(str(v))}</td></tr>' for k,v in data.items())
        b=f'<!doctype html><meta name="viewport" content="width=device-width"><title>RUDRILA Bot</title><h1>RUDRILA Bitget AI</h1><table>{rows}</table>'.encode()
        self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers(); self.wfile.write(b)
    def log_message(self,*a): pass

def serve(host='0.0.0.0',port=8080): ThreadingHTTPServer((host,port),DashboardHandler).serve_forever()
