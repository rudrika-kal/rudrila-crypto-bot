from __future__ import annotations
import asyncio, json, time, uuid
from dataclasses import dataclass, field
from .engine_06_10 import SignalEngine0610
from .volatility_execution import VolatilityExecutionFamily
from .news_macro import NewsMacroEngine
from .news_feeds import LiveNewsCollector,SOURCE_CLASSES
from .consensus import consensus
from .entry_rules import EntryRules
from .regime import RegimeDetector
from .risk import RiskEngine
from .exits import ExitPlanner
from .safety_layer import EmergencySafetyLayer
from .journal import TradeJournal
from .health import HealthState
from .rest_client import BitgetREST, normalize_qty
from .bitget_execution import DemoOrderExecutor
from .private_ws import BitgetPrivateDemoWS
from .mtf import MultiTimeframeTrend
from .breaking_news import BreakingNewsGuard
from .signals import FamilyScore

@dataclass
class RuntimeSymbol:
    engine: SignalEngine0610 = field(default_factory=SignalEngine0610)
    vol: VolatilityExecutionFamily = field(default_factory=VolatilityExecutionFamily)
    regime: RegimeDetector = field(default_factory=RegimeDetector)
    mtf: MultiTimeframeTrend = field(default_factory=MultiTimeframeTrend)
    last_seen_open_ts:int=0
    last_seen_5m_ts:int=0
    last_processed_5m_ts:int=0
    last_seen_15m_ts:int=0
    last_processed_15m_ts:int=0
    last_processed_closed_ts:int=0
    last_scores:dict=field(default_factory=dict)
    last_entry_ms:int=0

class DemoTradingRuntime:
    def __init__(self,settings,config):
        self.s=settings; self.c=config; self.symbols=tuple(config.get('symbols',['BTCUSDT','ETHUSDT']))
        self.rest=BitgetREST(settings); self.exec=DemoOrderExecutor(settings); self.pws=BitgetPrivateDemoWS(self.exec)
        self.state={s:RuntimeSymbol() for s in self.symbols}
        self.news_engine=NewsMacroEngine(); self.news_collector=LiveNewsCollector(); self.news_score=FamilyScore.build('news_macro',0,0); self.news_last_ms=0; self.breaking=BreakingNewsGuard()
        self.entry=EntryRules(config['decision']['base_entry_score'],config['decision']['minimum_aligned_families'])
        r=config['risk']; self.risk=RiskEngine(r['risk_per_trade_pct'],r['max_daily_loss_pct'],r['max_total_drawdown_pct'],r['max_open_positions'],r['max_same_direction_correlated_positions'])
        self.exits=ExitPlanner(); e=config['execution']; self.safety=EmergencySafetyLayer(e['max_spread_pct'],e['stale_market_data_ms'])
        self.journal=TradeJournal(); self.health=HealthState(); self.instruments={}
        self.day_start_equity=None; self.equity_peak=None; self.account_equity=None

    async def _news_loop(self):
        while True:
            now=int(time.time()*1000)
            try:
                items=await asyncio.to_thread(self.news_collector.fetch)
                self.news_score=self.news_engine.aggregate(items,SOURCE_CLASSES,now) if items else self.news_engine.aggregate([],{},now)
                signed=self.news_engine.last.get('signed_score',0)
                stories=self.news_engine.last.get('stories') or []
                headline=stories[0].get('title','') if stories else ''
                self.breaking.ingest(signed,headline,now)
            except Exception:
                self.news_score=self.news_engine.aggregate([],{},now)
            self.news_last_ms=now
            await asyncio.sleep(30)

    def _equity_from_private(self):
        # account WS is authoritative when available; REST is startup fallback
        for msg in reversed(self.exec.state.fills[-1:]): pass
        if self.account_equity is not None: return self.account_equity
        try:
            data=self.rest.account_assets().get('data') or []
            if isinstance(data,list):
                total=0.0
                for row in data:
                    try: total += float(row.get('usdValue') or row.get('equity') or 0)
                    except Exception: pass
                if total>0: self.account_equity=total
        except Exception: pass
        return self.account_equity or 1000.0

    def _private_message(self,msg):
        if (msg.get('arg') or {}).get('topic')=='account':
            for d in msg.get('data') or []:
                x=d.get('totalEquity')
                if x is not None:
                    try: self.account_equity=float(x)
                    except Exception: pass

    async def prewarm(self):
        for sym in self.symbols:
            ins=self.rest.instruments(sym).get('data') or []
            if not ins or ins[0].get('status')!='online': raise RuntimeError(f'{sym} not online')
            self.instruments[sym]=ins[0]
            rows=self.rest.candles(sym,'1m',limit=300).get('data') or []
            for row in sorted(rows,key=lambda x:int(x[0])):
                _,o,h,l,c,v,*_=row
                vals=tuple(map(float,(o,h,l,c,v)))
                self.state[sym].engine.update_candle(*vals)
                self.state[sym].mtf.update_1m(*vals)
            for interval,method in [('5m',self.state[sym].mtf.update_5m),('15m',self.state[sym].mtf.update_15m)]:
                tfrows=self.rest.candles(sym,interval,limit=300).get('data') or []
                for row in sorted(tfrows,key=lambda x:int(x[0])):
                    _,o,h,l,c,v,*_=row; method(*map(float,(o,h,l,c,v)))

    async def run(self,public_ws,seconds=3600):
        await self.prewarm()
        eq=self._equity_from_private(); self.day_start_equity=eq; self.equity_peak=eq
        private_task=asyncio.create_task(self.pws.run(self._private_message))
        public_task=asyncio.create_task(public_ws.run_once(seconds))
        news_task=asyncio.create_task(self._news_loop())
        start=time.monotonic()
        try:
            while time.monotonic()-start < seconds:
                await asyncio.sleep(.25)
                if private_task.done():
                    exc=private_task.exception()
                    raise RuntimeError(f'private websocket stopped: {exc}')
                if public_task.done() and time.monotonic()-start < seconds-1:
                    exc=public_task.exception()
                    raise RuntimeError(f'public websocket stopped: {exc}')
                eq=self._equity_from_private(); self.equity_peak=max(self.equity_peak or eq,eq)
                for sym in self.symbols:
                    st=public_ws.states[sym]
                    rs=self.state[sym]
                    for tf,last_seen_attr,last_proc_attr,method in [
                        ('5m','last_seen_5m_ts','last_processed_5m_ts',rs.mtf.update_5m),
                        ('15m','last_seen_15m_ts','last_processed_15m_ts',rs.mtf.update_15m)]:
                        trows=st.candles[tf]
                        if trows:
                            cur=int(trows[-1][0]); last_seen=getattr(rs,last_seen_attr)
                            if last_seen==0: setattr(rs,last_seen_attr,cur)
                            elif cur!=last_seen and len(trows)>=2:
                                setattr(rs,last_seen_attr,cur); prevtf=trows[-2]; pts_tf=int(prevtf[0])
                                if pts_tf>getattr(rs,last_proc_attr):
                                    _,oo,hh,ll,cc,vv,*_=prevtf; method(*map(float,(oo,hh,ll,cc,vv))); setattr(rs,last_proc_attr,pts_tf)
                    rows=st.candles['1m']
                    if not rows: continue
                    row=rows[-1]
                    # Use a candle only once. Signals are built on completed bars; live current bar is ignored until timestamp changes.
                    try: ts=int(row[0])
                    except Exception: continue
                    if rs.last_seen_open_ts==0:
                        rs.last_seen_open_ts=ts; continue
                    if ts==rs.last_seen_open_ts: continue
                    # A new candle opened, so the prior cached candle is now closed.
                    prev=rows[-2] if len(rows)>=2 else None
                    rs.last_seen_open_ts=ts
                    if not prev: continue
                    pts,po,ph,pl,pc,pv,*_=prev
                    pts=int(pts)
                    if pts<=rs.last_processed_closed_ts: continue
                    rs.last_processed_closed_ts=pts
                    o,h,l,c,v=map(float,(po,ph,pl,pc,pv))
                    scores=rs.engine.update_candle(o,h,l,c,v,book=st.books5,trades=st.trades,bid=st.bid,ask=st.ask,funding_rate=st.funding_rate,open_interest=st.open_interest)
                    rs.mtf.update_1m(o,h,l,c,v)
                    scores['trend']=rs.mtf.score()
                    depth=0.0
                    if st.books5:
                        for side in ('b','a'):
                            for z in (st.books5.get(side) or [])[:5]:
                                try: depth += float(z[0])*float(z[1])
                                except Exception: pass
                    vs=rs.vol.update(h,l,c,st.bid,st.ask,depth)
                    ns=self.news_score
                    scores['volatility_execution']=vs; scores['news_macro']=ns
                    co=consensus(scores)
                    adx=rs.mtf.last.get('adx5') or rs.engine.trend.last.get('adx',0); bbw=rs.vol.last.get('bb_width_pct',0)
                    br=bool(rs.engine.structure.last.get('breakout_up') or rs.engine.structure.last.get('breakout_down'))
                    regime=rs.regime.update(c,rs.vol.last.get('atr',0),adx,st.spread_pct,bbw,br)
                    dl=(self.day_start_equity-eq)/self.day_start_equity*100 if self.day_start_equity else 0
                    dd=(self.equity_peak-eq)/self.equity_peak*100 if self.equity_peak else 0
                    now_ms=int(time.time()*1000)
                    safe=self.safety.evaluate(now_ms=now_ms,last_market_ms=st.last_update_ms,spread_pct=st.spread_pct,expected_slippage_pct=None,ws_connected=public_ws is not None and not st.is_stale(),account_synced=self.pws.logged_in,daily_loss_hit=dl>=self.risk.max_daily_loss_pct,drawdown_hit=dd>=self.risk.max_drawdown_pct)
                    candle_ret=(c/o-1)*100 if o else 0.0
                    bcheck=self.breaking.evaluate(now_ms,candle_ret,scores['order_flow'].direction)
                    cooldown=(now_ms-rs.last_entry_ms)<120_000 if rs.last_entry_ms else False
                    ed=self.entry.decide(co,regime,breaking_allow=bcheck['allow'],risk_allow=safe.allow_new_entries,cooldown=cooldown)
                    fam={k:{'long':x.long,'short':x.short,'direction':x.direction,'veto':x.veto} for k,x in scores.items()}
                    did=self.journal.log_decision(ts_ms=pts,symbol=sym,regime=regime,side=co.direction,composite=max(co.long_score,co.short_score),aligned=co.aligned_families,news=self.news_engine.last.get('signed_score',0),families=fam,reason=ed.reason,entered=False)
                    if not ed.enter: continue
                    # Never stack same symbol while private state shows a position.
                    if any(k[0]==sym and float(v.get('size') or v.get('qty') or 0)>0 for k,v in self.exec.state.positions.items()): continue
                    fib=rs.engine.structure.last
                    ext=(fib.get('extensions') or {}).get('127.2')
                    side=ed.side
                    plan=self.exits.plan(side,c,rs.vol.last.get('atr',0),fib.get('swing_low'),fib.get('swing_high'),ext)
                    current_pos=[{'symbol':k[0],'side':str(k[1]).upper()} for k,v in self.exec.state.positions.items() if float(v.get('size') or v.get('qty') or 0)>0]
                    rd=self.risk.assess(eq,self.day_start_equity,self.equity_peak,c,plan.stop,side,current_pos,5)
                    if not rd.allow: continue
                    qty=normalize_qty(rd.qty,self.instruments[sym])
                    if qty<=0 or qty*c < float(self.instruments[sym].get('minOrderAmount') or 0): continue
                    order_side='buy' if side=='LONG' else 'sell'
                    body=self.exec.build_order(sym,order_side,qty,order_type='market',oid=f'RUD-{sym}-{pts}',take_profit=plan.tp2,stop_loss=plan.stop)
                    self.exec.place_order(body)
                    rs.last_entry_ms=now_ms
                    self.journal.db.execute('UPDATE decisions SET entered=1 WHERE id=?',(did,)); self.journal.db.commit()
                self.health.write({'status':'running','mode':'DEMO','private_ws':self.pws.logged_in,'equity':eq,'symbols':list(self.symbols),'news_errors':self.news_collector.errors,'ts_ms':int(time.time()*1000)})
        finally:
            self.pws.stop(); private_task.cancel(); public_task.cancel(); news_task.cancel(); self.journal.close()
