from __future__ import annotations
import json, urllib.parse, urllib.request
from decimal import Decimal, ROUND_DOWN
from .settings import BitgetSettings
from .bitget_auth import SignedRequest

class BitgetREST:
    def __init__(self, settings: BitgetSettings, timeout: int = 12):
        self.s=settings; self.timeout=timeout

    def _request(self, method:str, path:str, *, query:dict|None=None, body:dict|None=None, private=False):
        query=query or None
        qs=('?'+urllib.parse.urlencode(query)) if query else ''
        raw=json.dumps(body,separators=(',',':')) if body is not None else ''
        headers={'Content-Type':'application/json','User-Agent':'RUDRILA-Bitget-AI/1.1'}
        if private:
            headers.update(SignedRequest(method,path,query=query,body=raw).headers(self.s))
        url=self.s.rest_base+path+qs
        data=raw.encode() if body is not None else None
        req=urllib.request.Request(url,data=data,headers=headers,method=method.upper())
        with urllib.request.urlopen(req,timeout=self.timeout) as r:
            out=json.loads(r.read().decode())
        if str(out.get('code')) not in ('00000','0'):
            raise RuntimeError(f'Bitget API error {out}')
        return out

    def server_time(self):
        return self._request('GET','/api/v2/public/time')
    def instruments(self,symbol:str|None=None):
        q={'category':'USDT-FUTURES'}
        if symbol: q['symbol']=symbol
        return self._request('GET','/api/v3/market/instruments',query=q)
    def candles(self,symbol:str,interval='1m',limit=1000,start_ms=None,end_ms=None,history=False):
        path='/api/v3/market/history-candles' if history else '/api/v3/market/candles'
        if history: limit=min(int(limit),100)
        else: limit=min(int(limit),1000)
        q={'category':'USDT-FUTURES','symbol':symbol,'interval':interval,'limit':str(limit)}
        if start_ms is not None: q['startTime']=str(start_ms)
        if end_ms is not None: q['endTime']=str(end_ms)
        return self._request('GET',path,query=q)
    def orderbook(self,symbol:str,limit=5):
        return self._request('GET','/api/v3/market/orderbook',query={'category':'USDT-FUTURES','symbol':symbol,'limit':str(limit)})
    def recent_fills(self,symbol:str,limit=100):
        return self._request('GET','/api/v3/market/fills',query={'category':'USDT-FUTURES','symbol':symbol,'limit':str(limit)})

    def account_info(self): return self._request('GET','/api/v3/account/info',private=True)
    def account_settings(self): return self._request('GET','/api/v3/account/settings',private=True)
    def account_assets(self): return self._request('GET','/api/v3/account/assets',private=True)
    # Classic Futures Demo fallback. Some Bitget mobile Demo accounts expose
    # SUSDT/SBTC... synthetic assets while UTA v3 reports zero equity. These
    # endpoints use the same Demo API key and paptrading=1 header.
    def classic_accounts(self, product_type='USDT-FUTURES'):
        return self._request('GET','/api/v2/mix/account/accounts',query={'productType':product_type},private=True)
    def classic_positions(self, product_type='USDT-FUTURES', margin_coin=None):
        q={'productType':product_type}
        if margin_coin: q['marginCoin']=margin_coin
        return self._request('GET','/api/v2/mix/position/all-position',query=q,private=True)
    def classic_place_order(self, body:dict):
        return self._request('POST','/api/v2/mix/order/place-order',body=body,private=True)
    def set_hold_mode(self,mode='one_way_mode'):
        return self._request('POST','/api/v3/account/set-hold-mode',body={'holdMode':mode},private=True)
    def set_leverage(self,symbol:str,leverage='2',margin_mode='crossed'):
        return self._request('POST','/api/v3/account/set-leverage',body={'category':'USDT-FUTURES','symbol':symbol,'leverage':str(leverage),'marginMode':margin_mode},private=True)


def _floor_to_step(value:float, step:float, precision:int)->float:
    if step <= 0: step = 10 ** (-precision)
    v=Decimal(str(value)); s=Decimal(str(step))
    units=(v/s).to_integral_value(rounding=ROUND_DOWN)
    q=units*s
    quant=Decimal('1').scaleb(-precision)
    return float(q.quantize(quant,rounding=ROUND_DOWN))


def normalize_qty(qty:float, instrument:dict)->float:
    precision=int(instrument.get('quantityPrecision') or 8)
    step=float(instrument.get('quantityMultiplier') or 10**(-precision))
    q=_floor_to_step(qty,step,precision)
    min_q=float(instrument.get('minOrderQty') or 0)
    max_q=float(instrument.get('maxMarketOrderQty') or instrument.get('maxOrderQty') or 0)
    if q < min_q: return 0.0
    if max_q > 0: q=min(q,max_q)
    return q
